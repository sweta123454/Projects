import type { SubscriptionFlatModel } from "@renderer/store/subscription"

export type DB_Subscription = SubscriptionFlatModel & {
  id: string
}
