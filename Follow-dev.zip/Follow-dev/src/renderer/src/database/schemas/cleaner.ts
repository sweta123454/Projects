export type DB_Cleaner = {
  refId: string
  visitedAt: number
  type: "entry" | "feed"
}
