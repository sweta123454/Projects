export const LOCAL_DB_NAME = "FOLLOW_DB"
