import type { PropsWithChildren } from "react"

export const NoopChildren = ({ children }: PropsWithChildren) => children
