import { createContext } from "react"

export const MarkdownRenderContainerRefContext = createContext<HTMLElement | null>(null)
