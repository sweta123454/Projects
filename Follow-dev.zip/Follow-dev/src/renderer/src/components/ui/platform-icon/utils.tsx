import * as validator from "@renderer/lib/link-parser"

export const getSupportedPlatformIconName = (url: string) => {
  const safeUrl = parseSafeUrl(url)

  if (!safeUrl) {
    return false
  }

  return (
    Object.values(validator).find((parser) => {
      const res = parser(safeUrl)

      if (res.validate) {
        return true
      }
      return false
    })?.parserName || false
  )
}

const parseSafeUrl = (url: string) => {
  try {
    return new URL(url)
  } catch {
    return null
  }
}
