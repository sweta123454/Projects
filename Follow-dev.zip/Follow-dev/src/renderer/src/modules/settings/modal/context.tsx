import { createContextState } from "foxact/context-state"

export const [SettingTabProvider, useSettingTab, useSetSettingTab] = createContextState("")
