export enum DayOf {
  Today,
  Yesterday,
}
