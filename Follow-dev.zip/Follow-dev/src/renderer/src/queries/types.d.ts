export interface MutationBaseProps {
  onSuccess?: () => void
  onError?: (error: Error) => void
}

export {}
