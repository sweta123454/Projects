export const HotKeyScopeMap = {
  Home: ["home"],
  Menu: ["menu"],
  Modal: ["modal"],
}
