import type { SearchInstance } from "./types"

export const defineSearchInstance = (instance: SearchInstance) => instance
