/// <reference types="vite/client" />

declare module "*?asset" {
  const src: string
  export default src
}
