export { domMax as default } from "framer-motion"
