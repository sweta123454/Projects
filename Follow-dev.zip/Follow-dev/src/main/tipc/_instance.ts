import { tipc } from "@egoist/tipc/main"

export const t = tipc.create()

export type T = typeof t
